--[[
   File name: init.lua
   Author: speedsterkawaii

   Recreated script functions in luau
   Most of them are aliases

   Editing this script WILL break execution

   Feel free to paste this
]]


function error(...)
warn(...)
end

function info(...)
print(...)
end

function getthreadcontext()
return 3
end

function getidentity()
return 3
end

function getthreadidentity()
return 3
end

function setthreadidentity(identity)
return 3
end

function setidentity(identity)
return 3
end

function setthreadcontext(identity)
return 3
end

function identifyexecutor()
return "Nyx", "Sigma"
end

function getexecutorname()
return "Nyx"
end

function gethui()
return game:GetService("CoreGui")
end

function getfpscap() -- no fps offsets :(
return 60
end

function getscripterror(source) -- returns the error of a script
return dumpstring(source)
end

-- todo this in the future of nyx
function rconsoleclear() end
function rconsolecreate() end
function rconsoledestroy() end
function rconsoleinput() end
function rconsoleprint(txt) end
function consoleclear() end
function consolecreate() end
function consoledestroy() end
function consoleinput() end
function consoleprint(txt) end
function rconsolename(txt) end
function consolesettitle(txt) end

