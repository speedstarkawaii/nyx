local Players = game:GetService("Players")

-- Function to set walk speed
local function setWalkSpeed(character)
    if character then
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if humanoid then
            humanoid.WalkSpeed = 100
        end
    end
end

-- Event listener for character added
Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        setWalkSpeed(character)
    end)
end)

-- Ensure the script works for the local player if they are already in the game
local player = Players.LocalPlayer
if player then
    player.CharacterAdded:Connect(setWalkSpeed)
    if player.Character then
        setWalkSpeed(player.Character)
    end
end
