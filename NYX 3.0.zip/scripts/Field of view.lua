game.Workspace.Camera.FieldOfView = 120
-- 120 is wide, 75 is default