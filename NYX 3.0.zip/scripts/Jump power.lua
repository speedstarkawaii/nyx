local Players = game:GetService("Players")

local JUMP_POWER = 100

-- Function to set jump power
local function setJumpPower(character)
    if character then
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if humanoid then
            humanoid.JumpPower = JUMP_POWER
        end
    end
end

-- Event listener for character added
Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        setJumpPower(character)
    end)
end)

-- Ensure the script works for the local player if they are already in the game
local player = Players.LocalPlayer
if player then
    player.CharacterAdded:Connect(setJumpPower)
    if player.Character then
        setJumpPower(player.Character)
    end
end
